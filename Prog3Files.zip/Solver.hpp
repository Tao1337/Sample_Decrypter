//
//  Solver.hpp
//  Datastr_Prog3
//
//  Created by Austin Tao on 3/3/17.
//  Copyright © 2017 Austin Tao. All rights reserved.
//

#ifndef Solver_hpp
#define Solver_hpp

#include "tools.hpp"

#endif /* Solver_hpp */
